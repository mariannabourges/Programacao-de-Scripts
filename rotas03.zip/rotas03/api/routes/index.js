const controllerIndex = require('../controllers/indexControllers.js');

app.get('/', controllerIndex.indexControllers);

